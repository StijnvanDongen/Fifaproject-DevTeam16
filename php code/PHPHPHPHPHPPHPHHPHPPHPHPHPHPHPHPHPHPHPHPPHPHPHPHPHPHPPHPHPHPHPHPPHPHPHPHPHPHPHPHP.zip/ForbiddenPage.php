<?php

?>

<link rel="stylesheet" href="css/header.css">

<div class="ForbiddenContainer">
    <p class="forbiddenCode">403!</p>
    <p class="forbiddenText">Unfortunately, you do not have permission to view this page.</p>
    <a href="index.php" class="forbiddenButton">BACK TO HOME</a>
</div>

