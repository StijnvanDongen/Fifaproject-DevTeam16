<?php
require "header.php";

echo ("<div class=\"button\">
       <a href=\"hier moet de path naar exe \" download=\"hier moet de path naar exe \">
       <button class=\"btn\">
       <i class=\"fa fa-download\"></i> Download The C# File
       </button>
       </a>
       </div>");

require "footer.php";
