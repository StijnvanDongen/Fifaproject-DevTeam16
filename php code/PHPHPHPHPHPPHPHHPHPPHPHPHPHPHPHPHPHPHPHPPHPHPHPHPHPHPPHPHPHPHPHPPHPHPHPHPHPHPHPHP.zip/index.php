<?php
require "config2.php";
require "header.php";


echo "<div class=\"container\">
        <div class=\"info\">
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Culpa cupiditate doloribus eligendi eos error
                et ex, expedita harum incidunt maxime molestiae nesciunt nostrum odit quae quis, quod, soluta vel
                veniam.
                Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aperiam maiores recusandae vitae. Aliquam
                asperiores eveniet, incidunt molestias officia quasi quisquam tempore. Blanditiis consequatur deserunt
                doloremque ea id officiis possimus unde?
                Lorem ipsum dolor sit amet, consectetur adipisicing elit. Adipisci aliquam aliquid aperiam dignissimos
                doloremque ea earum enim, esse explicabo fuga iure nemo numquam perspiciatis quia quibsusdam saepe sequi
                sunt, voluptas?
                Lorem ipsum dolor sit amet, consectetur adipisicing elit. Accusantium ad, adipisci aut commodi culpa eos
                ex harum illo iure laboriosam minus nesciunt nostrum officia perferendis perspiciatis quo voluptate!
                Aspernatur, expedita.
                Lorem ipsum dolor sit amet, consectetur adipisicing elit. Alias autem commodi cum fugiat hic magnam
                minus molestias, mollitia quam quisquam quos sequi soluta suscipit tempora tenetur totam velit. Hic,
                nihil!
                Lorem ipsum dolor sit amet, consectetur adipisicing elit. Amet animi architecto dolores est et, harum,
                illo molestiae necessitatibus quas quia ratione repellendus sapiente voluptatum? Accusantium culpa cum
                dignissimos porro rem?
                Lorem ipsum dolor sit amet, consectetur adipisicing elit. Adipisci, aliquam blanditiis dolore dolorum
                est eveniet excepturi impedit magnam obcaecati quibusdam sed voluptas, voluptatum! Architecto autem
                commodi hic ipsum officia. Id?
                Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ad alias aliquam animi at commodi, corporis
                eaque enim eum eveniet excepturi ipsum iure minus non quam quasi unde velit? Deleniti, quis.
            </p>
        </div>
</div> ";
require "footer.php";